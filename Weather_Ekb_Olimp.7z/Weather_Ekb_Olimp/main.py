import os
import numpy as np
import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model
from tensorflow.keras.layers import Dense
from tkinter import filedialog, messagebox
import tkinter as tk
from tkinter import ttk

MODEL_PATH = "model/weather_model.h5"

class WeatherAIApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Прогноз погоды на 2025 год")
        self.root.geometry("500x400")
        self.model = None
        self.history = None

        self.data = None
        self.result = None

        self.create_widgets()

    def create_widgets(self):
        ttk.Button(self.root, text="Загрузить данные", command=self.load_data).pack(pady=5)
        ttk.Button(self.root, text="Обучить модель", command=self.train_model).pack(pady=5)
        ttk.Button(self.root, text="Загрузить модель", command=self.load_model).pack(pady=5)
        ttk.Button(self.root, text="Сделать прогноз", command=self.predict_weather).pack(pady=5)
        ttk.Button(self.root, text="Сохранить результат", command=self.save_forecast).pack(pady=5)
        ttk.Button(self.root, text="Показать график температуры", command=self.plot_forecast).pack(pady=5)
        ttk.Button(self.root, text="Показать график потерь", command=self.plot_loss).pack(pady=5)

    def load_data(self):
        path = filedialog.askopenfilename(filetypes=[("Text files", "*.txt")])
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as file:
                lines = file.readlines()
                self.data = np.array([[float(n) for n in line.strip().split()] for line in lines])
            messagebox.showinfo("Успех", "Данные загружены успешно")
        except Exception as e:
            messagebox.showerror("Ошибка", f"Не удалось загрузить данные: {e}")

    def train_model(self):
        if self.data is None or len(self.data) < 2:
            messagebox.showwarning("Внимание", "Сначала загрузите корректные данные")
            return
        X = self.data[:-1]
        y = self.data[1:]

        self.model = Sequential([
            Dense(64, activation='relu', input_shape=(12,)),
            Dense(64, activation='relu'),
            Dense(12)
        ])
        self.model.compile(optimizer='adam', loss='mse', metrics=['mae'])
        self.history = self.model.fit(X, y, epochs=500, verbose=0)

        os.makedirs("model", exist_ok=True)
        self.model.save(MODEL_PATH)
        messagebox.showinfo("Готово", "Модель обучена и сохранена")

    def load_model(self):
        if os.path.exists(MODEL_PATH):
            self.model = load_model(MODEL_PATH)
            messagebox.showinfo("Успех", "Модель загружена")
        else:
            messagebox.showwarning("Не найдено", "Файл модели отсутствует")

    def predict_weather(self):
        if self.model is None:
            messagebox.showerror("Ошибка", "Модель не загружена")
            return
        input_data = self.data[-1].reshape(1, -1)
        self.result = self.model.predict(input_data)[0]
        messagebox.showinfo("Прогноз", "Прогноз на 2025 год построен")

    def save_forecast(self):
        if self.result is None:
            messagebox.showwarning("Нет данных", "Сначала постройте прогноз")
            return
        with open("forecast_2025.txt", "w") as f:
            f.write(" ".join(map(lambda x: f"{x:.2f}", self.result)))
        messagebox.showinfo("Сохранено", "Прогноз сохранен в forecast_2025.txt")

    def plot_forecast(self):
        if self.result is None:
            messagebox.showwarning("Нет данных", "Сначала постройте прогноз")
            return
        months = ["Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек"]
        plt.figure(figsize=(10, 5))
        plt.plot(months, self.result, marker='o')
        plt.title("Прогноз температуры на 2025 год")
        plt.xlabel("Месяц")
        plt.ylabel("Температура, °C")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

    def plot_loss(self):
        if self.history is None:
            messagebox.showwarning("Нет обучения", "Сначала обучите модель")
            return
        plt.figure(figsize=(8, 5))
        plt.plot(self.history.history['loss'])
        plt.title("График потерь")
        plt.xlabel("Эпоха")
        plt.ylabel("MSE потери")
        plt.grid(True)
        plt.tight_layout()
        plt.show()

if __name__ == "__main__":
    root = tk.Tk()
    app = WeatherAIApp(root)
    root.mainloop()
